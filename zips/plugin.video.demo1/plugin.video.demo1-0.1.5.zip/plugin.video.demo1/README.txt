#forthelulz

complete explanation here 

http://www.desinerd.co.in/kodi-addon-development-sys-argv-explained-build-menu/